import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from metrics import *
def test_loop():
    assert is_loop("Det är en stad i Sverige. " * 20)
def test_varied():
    t = "Stockholm är Sveriges huvudstad och största stad med många öar, broar och museer längs vattnet."
    assert not is_loop(t) and sv_frac(t) > 0.8
def test_english():
    assert sv_frac("the cat is on the mat and it was a day for all of them") < 0.2
def test_boot():
    m, lo, hi = bootstrap_ci([1, 1, 0, 1, 0, 1]); assert lo <= m <= hi
if __name__ == "__main__":
    for k, f in list(globals().items()):
        if k.startswith("test_"): f(); print("ok", k)
